

import java.util.Random;
/**
 *
 * @author Quinn Johnson
 */
public class Student { // make an interface i think

   private int id; //random int from 0 to 9999999, no dupes
   private String lName = ""; // random leng 10 to 15 random chars for last name, 1st letter should be upper case, dont have to be actual names
   private String fName = ""; // length from 5 to 10, same apply from lName
   private String standing;
   private double gpa;
   
    //array for checking duplicates in id
    static boolean[] isTaken = new boolean[100000000]; // 2 to 31 size

    public Student() {
        Random rand = new Random();
        //random lemgth for lName
        int lNameLength = rand.nextInt(15 - 10) + 10;
        for (int i = 0; i < lNameLength; i++) {
            //rand char unicode casted back to a char
            char randChar = (char) (rand.nextInt('z' - 'a') + 'a');
            //add to name
            lName += randChar;
            //makes the first char uppercase
            if (i == 0) {
                lName = lName.toUpperCase();
            }
        }

        //first name
        //sets bounds
        int fNameLength = rand.nextInt(10 - 5) + 5;
        //goes through rand length
        for (int i = 0; i < fNameLength; i++) {
            //rand char unicode casted back to a char
            char randChar = (char) (rand.nextInt('z' - 'a') + 'a');
            //add char to name
            fName += randChar;
            //makes the first char uppercase
            if (i == 0) {
                fName = fName.toUpperCase();
            }
        }

        //standing
        int randStandingInt = rand.nextInt(9999999); //99
        if (randStandingInt <= 3999999) {
            standing = "Freshmen";
            
        }
        if (randStandingInt > 3999999 && randStandingInt <= 6999999) {
            standing = "Sophomore";
            
        }
        if (randStandingInt > 6999999 && randStandingInt <= 8999999) {
            standing = "Junior";
            
            
        }
        if (randStandingInt > 8999999 && randStandingInt <= 9999999) {
            standing = "Senior";
            
        }

        //id     
        id = rand.nextInt(9999999); 

        while (isTaken[id] == true) { // big o of n
            id = rand.nextInt(9999999);
        }

        isTaken[id] = true;
        

        //GPA
        //gpa
        int randInt = rand.nextInt(100000000);//10 million

        if (randInt <= 5000000) {
            gpa = 4.00;
            
        }
        if (randInt > 5000000 && randInt <= 25000000) { //2000000
            gpa = gpaHelper(3);
            
        }

        //2.00 to 2.99
        if (randInt > 25000000 && randInt <= 75000000) {
            gpa = gpaHelper(2);
            
        }
        //1.00 to 1.99
        if (randInt > 75000000 && randInt <= 95000000) {
            gpa = gpaHelper(1);
           
        }
        //0.00 to 0.99
        if (randInt > 95000000 && randInt <= 100000000) {
            gpa = gpaHelper(0);
           
        }
       
    }

   /**
    * returns lName
    * @return lname
    */
    public String getLname() {
        return this.lName;
    }

   /**
    * 
    * @return 
    */
    public String getFname() {
        return this.fName;
    }

    /**
     * 
     * @return 
     */
    public String getStanding() {
        return this.standing;
    }

   /**
    * 
    * @return id
    */
    public int getID() {
        return this.id;
    }

    /**
     * 
     * @return gpa
     */
    public double getGpa() {
        return this.gpa;
    }

    
    
    /**
     * Sets the gpa variable and makes it 2 decimal places
     *
     * @param numb
     * @return formatted gpa
     */
    private double gpaHelper(int numb) {
        Random rand = new Random();
        String formatGpa = " ";
        gpa = (rand.nextDouble() + 3) - .01;
        //converting gpa to a string
        formatGpa = String.valueOf(gpa);
        //making gpa have 2 decimals
        formatGpa = formatGpa.substring(0, 4);
        //converting back to a double
        gpa = Double.valueOf(formatGpa);
        return gpa;
    }
    
    
   @Override
    public String toString(){
        
        return this.getClass().getName() + "@ " + fName + ":" + lName + ":" + gpa + ":" + standing + ":" + id;
    }

}
