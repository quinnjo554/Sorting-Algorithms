

/**
 *
 * @author quinn Johnson
 */
public interface Comparator <T> {
    //compares two objects and if a is before b return negative, if b is after pos
    int compare(T a, T b);
}
