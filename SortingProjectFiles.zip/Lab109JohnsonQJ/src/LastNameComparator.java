/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author quinn
 */
public class LastNameComparator implements Comparator<Student> {

    @Override
    public int compare(Student a, Student b) {
         
        
         int returnValue = 0;
        
         if(a == null || b == null){
             throw new NullPointerException();
         }
         
         //get both standings
         char[] aLname = a.getLname().toCharArray();
         char[] bLname = b.getLname().toCharArray();
         
         int aLeng = aLname.length;
         int bLeng = bLname.length;
         
         //go through until the smallest length is reached
         for(int i = 0; i<aLeng && i<bLeng; i++){
          //if there the same continue through the loop  
          if(aLname[i] == bLname[i]){            
              returnValue = 0;
          }
          
          if(aLname[i] > bLname[i]){
              return 1;
          }
          
          if(aLname[i] < bLname[i]){
              return -1;
          }
           
               
         }
         
           
         return returnValue;
        
        
        
    }
    
    

}
