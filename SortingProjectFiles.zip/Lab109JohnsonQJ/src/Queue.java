
/**
 *
 *Queue Interface
 * Code Fragments 6.9
 * from
 * Data Structures & Algorithms, 6th edition
 * by Michael T.Goodrich, Roberto Tamassia &; Michael H. Goldwasser
 Wiley 2014
 Transcribed by
 * @author Quinn Johnson
 * 
 * @param <T>
 * interface for Queue structures
 *
 */
public interface Queue<T> {
     /** 
      * Returns the number of elements in the queue. 
     * @return 
      */
   int size( );
   /**
    * Tests whether the queue is empty. 
     * @return 
    */
   boolean isEmpty( );
   /** 
    * 
    * Inserts an element at the rear of the queue. 
     * @param t element to be added
     * @throws java.lang.IllegalStateException if stack is full // ask if it should be a custom exception
    */
   void enqueue(T t) throws IllegalStateException;
   /**
    * Returns, but does not remove, the first element of the queue (null if empty).
     * @return first element
    */
   T first( );
   /**
    * Removes and returns the first element of the queue (null if empty). 
     * @return removed element
    */
   T dequeue( );
}
