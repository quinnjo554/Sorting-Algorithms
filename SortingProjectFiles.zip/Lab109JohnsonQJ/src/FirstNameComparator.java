
/**
 *
 * @author quinn johnson
 */
public class FirstNameComparator implements Comparator<Student> {

    @Override
    public int compare(Student a, Student b) {
        int returnValue = 0;
        
         if(a == null || b == null){
             throw new NullPointerException();
         }
         
         //get both standings
         char[] aFname = a.getFname().toCharArray();
         char[] bFname = b.getFname().toCharArray();
         
         int aLeng = aFname.length;
         int bLeng = bFname.length;
         
         //go through until the smallest length is reached
         for(int i = 0; i<aLeng && i<bLeng; i++){
         //if there the same continue through the loop 
          if(aFname[i] == bFname[i]){            
              returnValue = 0;
          }
          
          if(aFname[i] > bFname[i]){
              return 1;
          }
          
           if(aFname[i] < bFname[i]){
              return -1;
          }
           
               
         }
         
         
        
        
         return returnValue;
        
    }
        
}
