
import java.util.Arrays;

/**
 * Merge sort and Quick Sort Code Fragments 12.1, 12.2, 12.5 from Data
 * Structures & Algorithms, 6th edition by Michael T.Goodrich, Roberto Tamassia
 * &; Michael H. Goldwasser Wiley 2014 Transcribed by
 *
 * @author quinn Johnson
 *
 * Class for sorting algorithums
 */
public class Sort {

    public <T> void bubbleSort(T[] data, Comparator comp) {

        T temp;

        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data.length - 1; j++) {
                //check the adjacent elements
                if (comp.compare(data[j], data[j + 1]) < 0) {
                    //swap
                    temp = data[j];
                    data[j] = data[j + 1];
                    data[j + 1] = temp;
                }
            }
        }

    }

    public <T> void efficaantBubbleSort(T[] data, Comparator comp) {

        T temp;
        for (int i = 0; i < data.length - 1; i++) {
            for (int j = 0; j < data.length - i - 1; j++) {
                //check the adjacent elements
                if (comp.compare(data[j], data[j + 1]) <= 0) {
                    //swap
                    temp = data[j];
                    data[j] = data[j + 1];
                    data[j + 1] = temp;
                }
            }
        }
    }

    public <T> void selectionSort(T[] data, Comparator comp) {

        T temp; //temp location for swap
        int max; //index of max value in subarray

        for (int i = 0; i < data.length - 1; i++) {
            //find largest value
            max = indexOfLargestElement(data, data.length - i, comp);

            //swap data[max] and data[data.length -i -1]
            temp = data[max];
            data[max] = data[data.length - i - 1];
            data[data.length - i - 1] = temp;
            //make it work with lastname comparator
        }

    }

    public <T> int indexOfLargestElement(T[] array, int size, Comparator comp) {

        int index = 0;
        for (int i = 1; i < size; i++) {
            if (comp.compare(array[i], array[index]) > 0) { //array[i] is larger than array[index] 
                index = i;
            }

        }
        return index;
    }

    public <T> void insertionSort(T[] data, Comparator comp) {
        int j;
        for (int i = 1; i < data.length; i++) {
            j = i;
            //Check hat currentIndex is at least 1 and that the item directly before the currentIndex is greater than the item at currentIndex
            while (j > 0 && comp.compare(data[j - 1], data[j]) > 0) {
                //if they are swap
                T temp = data[j];
                data[j] = data[j - 1];
                data[j - 1] = temp;
                j--;
            }

        }

    }

    /**
     *
     * @param <K>
     * @param S
     * @param comp
     */
    public <K> void mergeSort(K[] S, Comparator<K> comp) {
        int n = S.length;
        if (n < 2) {
            return;                              // array is trivially sorted
        }   // divide
        int mid = n / 2;
        K[] S1 = Arrays.copyOfRange(S, 0, mid);         // copy of first half
        K[] S2 = Arrays.copyOfRange(S, mid, n);         // copy of second half
        // conquer (with recursion)
        mergeSort(S1, comp);                            // sort copy of first half
        mergeSort(S2, comp);                            // sort copy of second half
        // merge results
        merge(S1, S2, S, comp);              // merge sorted halves back into original
    }

    
    /**
     * 
     * @param <K>
     * @param S1
     * @param S2
     * @param S
     * @param comp 
     */
    private <K> void merge(K[] S1, K[] S2, K[] S, Comparator<K> comp) {
        int i = 0, j = 0;
        while (i + j < S.length) {
            if (j == S2.length || (i < S1.length && comp.compare(S1[i], S2[j]) < 0)) {
                S[i + j] = S1[i++];               // copy ith element of S1 and increment i
            } else {
                S[i + j] = S2[j++];                // copy jth element of S2 and increment j
            }
        }
    }

    /**
     * Performs quick sort on a queue
     *
     * @param <K>
     * @param S
     * @param comp
     */
    public <K> void quickSort(Queue<K> S, Comparator<K> comp) {
        int n = S.size();
        if (n < 2) {
            return;                      // queue is trivially sorted
        }   // divide
        K pivot = S.first();                    // using first as arbitrary pivot
        Queue<K> L = new LinkedQueue<>();
        Queue<K> E = new LinkedQueue<>();
        Queue<K> G = new LinkedQueue<>();
        while (!S.isEmpty()) {                   // divide original into L, E, and G
            K element = S.dequeue();
            int c = comp.compare(element, pivot);
            if (c < 0) // element is less than pivot
            {
                L.enqueue(element);
            } else if (c == 0) // element is equal to pivot
            {
                E.enqueue(element);
            } else // element is greater than pivot
            {
                G.enqueue(element);
            }
        }
        // conquer
        quickSort(L, comp);                     // sort elements less than pivot
        quickSort(G, comp);                     // sort elements greater than pivot
        // concatenate results
        while (!L.isEmpty()) {
            S.enqueue(L.dequeue());
        }
        while (!E.isEmpty()) {
            S.enqueue(E.dequeue());
        }
        while (!G.isEmpty()) {
            S.enqueue(G.dequeue());
        }
    }

    /**
     * performs radixSort with data k
     *
     * @param <K>
     * @param data
     * @param comp1
     * @param comp2
     * @param comp3
     * @param comp4
     * @param comp5
     */
    public <K> void radixSort(K[] data, Comparator comp1, Comparator comp2, Comparator comp3, Comparator comp4, Comparator comp5) {

        this.mergeSort(data, comp5);
        this.mergeSort(data, comp4);
        this.mergeSort(data, comp3);
        this.mergeSort(data, comp2);
        this.mergeSort(data, comp1);

    }

}
