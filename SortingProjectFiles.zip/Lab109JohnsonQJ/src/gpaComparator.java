

/**
 *
 * @author Quinn Johnson
 */
public class gpaComparator implements Comparator<Student> {

    /**
     * compares gpa between to students
     * @param a
     * @param b
     * @return 
     */
    @Override
    public int compare(Student a, Student b) {
         int returnValue = 0;
        //if a or b is null throw an exception
         if(a == null || b == null){
             throw new NullPointerException();
         }
         
         double aGPA = a.getGpa();
         double bGPA = b.getGpa();
         
         // if a is larger than b
         if(aGPA > bGPA){
             returnValue = 1;
         }
          // if a is equal to b
         if(aGPA == bGPA){
             returnValue = 0;
         }
         //if a is less than b
         if(aGPA < bGPA){
             returnValue = -1;
         }
         return returnValue;
         
    }
    
}
