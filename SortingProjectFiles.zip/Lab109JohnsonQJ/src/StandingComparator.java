/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author quinn
 */
public class StandingComparator implements Comparator<Student> {

    @Override
    public int compare(Student a, Student b) {
       
        
         int returnValue = 0;
        
         if(a == null || b == null){
             throw new NullPointerException();
         }
         
         //get both standings
         String aStanding = a.getStanding();
         String bStanding = b.getStanding();
         
        //if aStanding is senoir
        if(aStanding.equals("Senior")){
            
            //everything else will return 1
            if(bStanding.equals("Senior")){
                returnValue = 0;
            }
            if(bStanding.equals("Junior")){
                returnValue = 1;
            }
            if(bStanding.equals("Sophomore")){
                returnValue = 1;
            }
             if(bStanding.equals("Freshmen")){
                returnValue = 1;
            }            
        }
        
        //if aStanding is junior then senior is the only one higher
        if(aStanding.equals("Junior")){
            
            if(bStanding.equals("Senior")){
                returnValue = -1;
            }
            if(bStanding.equals("Junior")){
                returnValue = 0;
            }
            if(bStanding.equals("Sophomore")){
                returnValue = 1;
            }
             if(bStanding.equals("Freshmen")){
                returnValue = 1;
            }            
        }
        //if aStanding is sophomore then senior and junior are higher
        if(aStanding.equals("Sophomore")){
            
            if(bStanding.equals("Senior")){
                returnValue = -1;
            }
            if(bStanding.equals("Junior")){
                returnValue = -1;
            }
            if(bStanding.equals("Sophomore")){
                returnValue = 0;
            }
             if(bStanding.equals("Freshmen")){
                returnValue = 1;
            }            
        }
        
        //if aStanding is Freshmen then all are higher
         if(aStanding.equals("Freshmen")){
            
            if(bStanding.equals("Senior")){
                returnValue = -1;
            }
            if(bStanding.equals("Junior")){
                returnValue = -1;
            }
            if(bStanding.equals("Sophomore")){
                returnValue = -1;
            }
             if(bStanding.equals("Freshmen")){
                returnValue = 0;
            }            
        }
        
        
        
         return returnValue;
        
        
        
    }
    
}
