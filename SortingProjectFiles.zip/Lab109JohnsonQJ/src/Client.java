
/**
 *
 * @author Quinn Johnson
 * makes use of the sorting algorithms and Comparators with the student class
 */
public class Client {

    public static void main(String[] args) {

        Sort sort = new Sort();
        Comparator idcomp = new IdComparator();
        Comparator gpaComp = new gpaComparator();
        Comparator standingComp = new StandingComparator();
        Comparator firstNameComp = new FirstNameComparator();
        Comparator lastNameComp = new LastNameComparator();
        LinkedQueue quickSort = new LinkedQueue();    
        
        
        //for nlogn sorts
        Student[] studentArray = new Student[1000000];
        for (int i = 0; i < studentArray.length; i++) {
            studentArray[i] = new Student();
        }

        Student[] student = new Student[10000];
        for (int i = 0; i < student.length; i++) {
            student[i] = new Student();
        }
       
        
        
        //2d array for storing data
        long table[][];
        table = new long[7][3];

        //table for headers
        String table2[];
        table2 = new String[7];

        //row counter to store elements in the for loop
        int rowCounter = 0;

        //varibales to measure the time
        long start;
        long stop;
        long total;

        int N = studentArray.length;

        //
        //Merge Sort id
        //
        //setting the first row
        table[0][0] = N;

        //array test start 
        start = System.currentTimeMillis();

        //Merge sort id
        sort.mergeSort(studentArray, idcomp);

        //end of array test
        stop = System.currentTimeMillis();

        total = stop - start;

        //table gets the data row 2 at collom 1
        table[0][1] = total;

        //
        //Quick Sort Gpa
        //
        //setting N at proper collum
        table[1][0] = N;

        //fills with new students to sort
        for (int i = 0; i < studentArray.length; i++) {
            studentArray[i] = new Student();
        }

        //putting student array into a queue
        for (int i = 0; i < studentArray.length; i++) {
            quickSort.enqueue(studentArray[i]);
        }
        //test Start
        start = System.currentTimeMillis();

        sort.quickSort(quickSort, gpaComp);

        stop = System.currentTimeMillis();
        //end of test

        total = stop - start;

        //setting table data
        table[1][1] = total;

        //
        //Bubble sort
        //
        //fills with new students to sort
        for (int i = 0; i < student.length; i++) {
            student[i] = new Student();
        }

        //set N to appropriate length
        N = student.length;
        table[2][0] = N;

        // test start 
        start = System.currentTimeMillis();

        //buuble sort id
        sort.mergeSort(studentArray, idcomp);

        //end of array test
        stop = System.currentTimeMillis();

        total = stop - start;

        //table gets the data row 2 at collom 1
        table[2][1] = total;

        //
        //efficant Bubble sort id
        //
        //fills with new students to sort
        for (int i = 0; i < student.length; i++) {
            student[i] = new Student();
        }

        //set N to appropriate length
        N = student.length;
        table[3][0] = N;

        //test start 
        start = System.currentTimeMillis();

        //Efficant bubble sort id
        sort.efficaantBubbleSort(student, idcomp);

        //end of array test
        stop = System.currentTimeMillis();

        total = stop - start;

        //table gets the data row 2 at collom 1
        table[3][1] = total;

        //
        //Insertion sort GPA
        //
        
        //fills with new students to sort
        for (int i = 0; i < student.length; i++) {
            student[i] = new Student();
        }

        //set N to appropriate length
        N = student.length;
        table[4][0] = N;

        // test start 
        start = System.currentTimeMillis();

        //Efficant bubble sort id
        sort.insertionSort(student, gpaComp);

        //end of array test
        stop = System.currentTimeMillis();

        total = stop - start;

        //table gets the data row 2 at collom 1
        table[4][1] = total;

        //
        //Insertion sort Standing
        //
        //fills with new students to sort
        for (int i = 0; i < student.length; i++) {
            student[i] = new Student();
        }

        //set N to appropriate length
        N = student.length;
        table[5][0] = N;

        // test start 
        start = System.currentTimeMillis();

        //Efficant bubble sort id
        sort.insertionSort(student, standingComp);

        //end of array test
        stop = System.currentTimeMillis();

        total = stop - start;

        //table gets the data row 2 at collom 1
        table[5][1] = total;

        //
        //radixSort sort Standing
        //
        //fills with new students to sort
        for (int i = 0; i < studentArray.length; i++) {
            studentArray[i] = new Student();
        }

        //set N to appropriate length
        N = studentArray.length;
        table[6][0] = N;

        // test start 
        start = System.currentTimeMillis();

        //Efficant bubble sort id
        sort.radixSort(studentArray, firstNameComp, lastNameComp, standingComp, gpaComp, idcomp);

        //end of array test
        stop = System.currentTimeMillis();

        total = stop - start;

        //table gets the data row 2 at collom 1
        table[6][1] = total;

        //draw the table 
        asciiTable(table, table2);

        //quick sort use the queue 
        //quick sort2 (array comparator) convert the array in the queue then call the queue quick sort
        //queue to array start at array[0]
    }

    /**
     * Takes a 2D array and displays its contents on a ascii table
     *
     * @param table
     * @param table2
     */
    public static void asciiTable(long table[][], String table2[]) {

        table2[0] = "Merge";
        table2[1] = "Quick";
        table2[2] = "SimBubble";
        table2[3] = "EffiBubble";
        table2[4] = "Insertion";
        table2[5] = "Selection";
        table2[6] = "Radix";

        System.out.printf("+---------------+----------+---------------------+\n");
        System.out.printf("|       N       |  Time    |   Sort              |\n");
        System.out.printf("+---------------+----------+---------------------+\n");
        for (int i = 0; i < table.length; i++) {
            System.out.printf("|  %,11d  |  %,5d   | %10s          |\n", table[i][0], table[i][1], table2[i]); // 11 digits, 4 digits, 6 digits, 
            System.out.printf("+---------------+----------+---------------------+\n");
        }
    }

    /**
     * Prints elements from given array
     *
     * @param data
     */
    public static void printArray(Student[] data) {

        for (int i = 0; i < data.length; i++) {

            System.out.println(data[i].getID());

        }

    }

}
