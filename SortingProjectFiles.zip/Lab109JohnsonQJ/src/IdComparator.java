

/**
 *
 * @author quinn johnson
 */
public class IdComparator implements Comparator<Student> {

    @Override
    /**
     * compares student a to b
     */
    public int compare(Student a, Student b) {
        int returnValue = 0;
        
        //if null throw exception 
         if(a == null || b == null){
             throw new NullPointerException();
         }
         
         int aId = a.getID();
         int bId = b.getID();
         
         //a is larger than b
         if(aId > bId){
             returnValue = 1;
         }
         //a == b
         if(aId == bId){
             returnValue = 0;
         }
         //a less b
         if(aId < bId){
             returnValue = -1;
         }
         return returnValue;
         
         
    }
    
}
